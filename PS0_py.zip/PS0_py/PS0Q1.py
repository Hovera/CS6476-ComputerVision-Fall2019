# %% 4
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

# create a 100 x 100 matrix using integers from 0 to 9999, in increasing order.
aa = np.arange(0, 10000)
A = aa.reshape(100, 100)

# save into the same directory as this script
np.save('inputAPS0Q1', A)

# load npy file
A = np.load('inputAPS0Q1.npy')

# %% 4(a)

# Sort A, by default it is in ascending order
B = np.sort(A, axis=None)

# Reverse the order of sorted vector, so now it is in decreasing order.
B = B[::-1]

# Plot the intensities in grayscale in a decreasing order.
plt.imshow(np.atleast_2d(B), cmap='gray', extent=(0, 9999, 0, 500))

# hide the y axis because it is simply the height of the bar, doesn't have
# meaning
plt.yticks([])

# %% 4(b)

# reshape A into 1d array
C = A.reshape(-1)

# set a bigger plot size
figure = plt.figure(figsize=(16, 8))

# set tick interval to be 500 so we have 20 ticks displayed (by default the
# intervals are 2000)
plt.xticks(np.arange(0, 9999, step=500))

# plot histogram of 20 bins based on reshaped A, set edgecolor to be black
plt.hist(C, bins=20, ec='black')

# Note that in this case all bins have same counts(500) because my initial A
# is consecutive integers fro 0 to 9999 which gives same counts for
# each bin.

# %% 4(c)

# bottom left quadrant means to slice A by row 50-99 and column 0-49
X = A[50:100, 0:50]

figure = plt.figure(figsize=(5, 5))
plt.imshow(X, cmap='gray', interpolation='None')

np.save('outputXPS0Q1', X)

# %% 4(d)

# calculate mean intensity of A.

A_mean = A.mean()

Y = A.astype(float) - A_mean

figure = plt.figure(figsize=(5, 5))

# Since the problem didn't specify about interpolation, I leave it as default.
plt.imshow(Y, cmap='gray')

np.save('outputYPS0Q1', Y)


# %% 4(e)

t = A_mean

Z = np.zeros((100, 100, 3), 'float')

for i in range(0, 100, 1):
    for j in range(0, 100, 1):
        if A[i][j] > t:
            Z[i, j] = (1.0, 0, 0)

plt.imshow(Z)
plt.imsave('outputZPS0Q1.png', Z)

