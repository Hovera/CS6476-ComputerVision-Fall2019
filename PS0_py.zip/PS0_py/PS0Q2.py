import numpy as np
import matplotlib.pyplot as plt

img = plt.imread("inputPS0Q2.jpg")
plt.imshow(img)

# %%

# 2.1 Swap red and green channels
img_swap = img.copy()

temp = img_swap[:, :, 1].copy()
img_swap[:, :, 1] = img_swap[:, :, 0].copy()
img_swap[:, :, 0] = temp

# 2.2 Convert to grayscale image


def rgb2gray(rgb):
    return np.dot(rgb[..., :3], [0.2989, 0.5870, 0.1140])


gray_img = rgb2gray(img).astype(float)


# 2.3(a)
img_neg = gray_img.copy()
img_neg = 255.0 - img_neg

# 2.3(b)
img_flip = gray_img.copy()
img_flip = np.flip(gray_img, 1)

# 2.3(c)
img_avg = (img_flip + gray_img) / 2.0

# 2.3(d)
'''
This is not a good implementation because it uses for loop. However, using
python's inbuilt function random allows us to generate floating numbers from
0.0 to 255.0, whereas using no only generates integers.

import random
N = np.zeros(row * col)

for i in range(0, row * col):
    N[i] = random.uniform(0, 255)

N.reshape(row,col)
np.save('noise', N)
'''

row = len(gray_img)
col = len(gray_img[0])
N = np.random.random_integers(low=0, high=255, size=(row, col))
np.save('noise', N)

img_add = N + gray_img
img_add[img_add >= 255.0] = 255

# %% Create subplots

fig, axes = plt.subplots(nrows=3, ncols=2, figsize=(10, 10))
fig.tight_layout()
fig.subplots_adjust(hspace=0.3)

axes[0, 0].imshow(img_swap)
axes[0, 0].title.set_text('Swap Red and Green Channels')
plt.imsave('swapImgPS0Q2.png', img_swap)

axes[0, 1].imshow(gray_img, cmap=plt.get_cmap('gray'))
axes[0, 1].title.set_text('Gray Scale')
plt.imsave('grayImgPS0Q2.png', gray_img, cmap='gray')

axes[1, 0].imshow(img_neg, cmap=plt.get_cmap('gray'))
axes[1, 0].title.set_text('Negative Image')
plt.imsave('negativeImgPS0Q2.png', img_neg, cmap='gray')

axes[1, 1].imshow(img_flip, cmap=plt.get_cmap('gray'))
axes[1, 1].title.set_text('Mirror Image: Flip from Left to Right')
plt.imsave('mirrorImgPS0Q2.png', img_flip, cmap='gray')

axes[2, 0].imshow(img_avg, cmap=plt.get_cmap('gray'))
axes[2, 0].title.set_text('Average of Mirror Image and Grayscale Image')
plt.imsave('avgImgPS0Q2.png.', img_avg, cmap='gray')

axes[2, 1].imshow(img_add, cmap=plt.get_cmap('gray'))
axes[2, 1].title.set_text('Grayscale Added with Noise')
plt.imsave('addNoiseImgPS0Q2.', img_add, cmap='gray')
